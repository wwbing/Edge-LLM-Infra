# Demo for CMake package usage

This folder demonstrates how to use eventpp as CMake package.  
See the project readme.md for how to build the demo program.

