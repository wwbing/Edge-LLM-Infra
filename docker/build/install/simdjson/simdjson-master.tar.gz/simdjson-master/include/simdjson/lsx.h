#ifndef SIMDJSON_LSX_H
#define SIMDJSON_LSX_H

#include "simdjson/lsx/begin.h"
#include "simdjson/generic/amalgamated.h"
#include "simdjson/lsx/end.h"

#endif // SIMDJSON_LSX_H
